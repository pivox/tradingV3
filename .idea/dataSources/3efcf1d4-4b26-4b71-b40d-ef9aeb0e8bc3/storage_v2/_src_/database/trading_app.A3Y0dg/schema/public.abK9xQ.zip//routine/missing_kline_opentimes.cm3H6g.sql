create function missing_kline_opentimes(p_symbol text, p_timeframe text, p_start timestamp without time zone, p_end timestamp without time zone)
    returns TABLE(missing_open_time timestamp with time zone)
    language plpgsql
as
$$
BEGIN
    -- Conversion explicite en timestamptz en assumant UTC
    RETURN QUERY
SELECT *
FROM missing_kline_opentimes(
    p_symbol,
    p_timeframe,
    p_start AT TIME ZONE 'UTC',
    p_end   AT TIME ZONE 'UTC'
     );
END;
$$;

alter function missing_kline_opentimes(text, text, timestamp, timestamp) owner to postgres;

