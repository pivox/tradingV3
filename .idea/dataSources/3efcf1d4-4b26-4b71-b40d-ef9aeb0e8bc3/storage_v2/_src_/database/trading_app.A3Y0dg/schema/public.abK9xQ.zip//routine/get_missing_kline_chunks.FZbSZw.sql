create function get_missing_kline_chunks(p_symbol text, p_timeframe text, p_start timestamp with time zone, p_end timestamp with time zone, p_max_per_request integer DEFAULT 500)
    returns TABLE(symbol text, step integer, "from" bigint, "to" bigint)
    language plpgsql
as
$$
DECLARE
    v_step_min INTEGER;
    v_step_interval INTERVAL;
BEGIN
    -- Validation des paramètres
    IF p_end <= p_start THEN
        RAISE EXCEPTION 'p_end (=%) doit être > p_start (=%)', p_end, p_start;
    END IF;

    -- Déterminer le step en minutes et l'intervalle
    CASE p_timeframe
        WHEN '1m' THEN
            v_step_min := 1;
            v_step_interval := interval '1 minute';
        WHEN '5m' THEN
            v_step_min := 5;
            v_step_interval := interval '5 minutes';
        WHEN '15m' THEN
            v_step_min := 15;
            v_step_interval := interval '15 minutes';
        WHEN '1h' THEN
            v_step_min := 60;
            v_step_interval := interval '1 hour';
        WHEN '4h' THEN
            v_step_min := 240;
            v_step_interval := interval '4 hours';
        WHEN '1d' THEN
            v_step_min := 1440;
            v_step_interval := interval '1 day';
        ELSE
            RAISE EXCEPTION 'Timeframe inconnu: % (attendu: 1m,5m,15m,1h,4h,1d)', p_timeframe;
    END CASE;

    -- Retourner les chunks manquants
    RETURN QUERY
    WITH
        missing AS (
            SELECT m.missing_open_time AS open_time, v_step_interval AS v_step
            FROM missing_kline_opentimes(p_symbol, p_timeframe, p_start, p_end) AS m
        ),
        runs AS (
            SELECT
                open_time,
                v_step,
                (open_time - (row_number() OVER (ORDER BY open_time)) * v_step) AS grp
            FROM missing
        ),
        ranges AS (
            SELECT
                min(open_time) AS range_start,
                max(open_time) + MIN(v_step) AS range_end_excl,
                count(*) AS candles_missing,
                MIN(v_step) AS v_step
            FROM runs
            GROUP BY grp
        ),
        chunked AS (
            SELECT
                r.range_start,
                r.range_end_excl,
                r.candles_missing,
                r.v_step,
                p_max_per_request AS max_per_request,
                v_step_min AS step_min,
                gs.idx AS chunk_index,
                LEAST(p_max_per_request,
                      r.candles_missing - (gs.idx * p_max_per_request)) AS chunk_size,
                (r.range_start + (gs.idx * p_max_per_request) * r.v_step) AS chunk_start,
                (r.range_start + (gs.idx * p_max_per_request
                   + LEAST(p_max_per_request, r.candles_missing - (gs.idx * p_max_per_request))) * r.v_step) AS chunk_end_excl
            FROM ranges r
            CROSS JOIN LATERAL generate_series(
                0,
                GREATEST(ceil((r.candles_missing::numeric) / p_max_per_request)::int - 1, 0)
            ) AS gs(idx)
        )
    SELECT
        p_symbol AS symbol,
        v_step_min AS step,
        extract(epoch from chunk_start)::bigint AS "from",
        extract(epoch from chunk_end_excl)::bigint AS "to"
    FROM chunked
    ORDER BY chunk_start, chunk_index;
END;
$$;

alter function get_missing_kline_chunks(text, text, timestamp with time zone, timestamp with time zone, integer) owner to postgres;

